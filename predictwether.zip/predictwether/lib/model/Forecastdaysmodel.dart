class Forecastdaysmodel{
  var _datatime;
  var _temp;
  String _main;
  String _description;


  Forecastdaysmodel(this._datatime, this._temp, this._main, this._description);

  String get description => _description;

  String get main => _main;

  get temp => _temp;

  get datatime => _datatime;


}