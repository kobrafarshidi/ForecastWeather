import 'dart:async';

import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:predictwether/model/CurrentCityDatamodel.dart';
import 'package:progress_indicators/progress_indicators.dart';
import 'package:intl/intl.dart';
import 'package:predictwether/model/Forecastdaysmodel.dart';



void main() {
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyApp()
  )
  );
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late Future<CurrentCityDatamodel> currentwetherfuture;
  late StreamController<List<Forecastdaysmodel>> streamforecastdays;
  var cityname="tabriz";
  var lat;
  var lon;
  TextEditingController textEditingController=TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    currentwetherfuture=SendRequestCurrentweather(cityname);
    streamforecastdays=StreamController<List<Forecastdaysmodel>>();

  }

  @override

  Widget build(BuildContext context) {
    return Scaffold(

      // appBar: AppBar(),

      body:
      FutureBuilder<CurrentCityDatamodel>(
        future: currentwetherfuture,
        builder: (context,snapshot){
          if(snapshot.hasData){
            CurrentCityDatamodel? cityDatamodel=snapshot.data;
            SendRequestSenvendaysforecast(lat, lon);
            final formatter=DateFormat.jm();
            var sunrise=formatter.format(
                new DateTime.fromMillisecondsSinceEpoch(
                    cityDatamodel!.sunrise*1000,
                    isUtc:false
                )
            );
            var sunset=formatter.format(
                new DateTime.fromMillisecondsSinceEpoch(
                    cityDatamodel.sunset*1000,
                    isUtc:false
                )
            );
            return
              Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        fit: BoxFit.cover,
                        //  height: MediaQuery.of(context).size.width,
                        image: AssetImage('images/pic1.jpg')
                    )
                ),
                child: Center(
                  child: Column(
                    children: [

                      Padding(
                        padding: const EdgeInsets.only(top: 40,right: 20,left: 20),
                        child: Row(children: [

                          Expanded(child:
                          TextField(
                            style: TextStyle(color: Colors.white),
                            controller: textEditingController,
                            decoration: InputDecoration(border: UnderlineInputBorder( borderSide: BorderSide(color: Colors.white),),hintText: "inter your city name",hintStyle: TextStyle(color: Colors.grey[600])),
                          )),
                          ElevatedButton(style: ElevatedButton.styleFrom(
                              primary: Colors.purple[900],
                              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                              textStyle: TextStyle(
                                  color: Colors.white,
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold))
                              ,onPressed: (){
                                setState(() {
                                  currentwetherfuture= SendRequestCurrentweather(textEditingController.text);
                                });


                              }, child: Text("Find",style: TextStyle(color: Colors.white,fontSize: 20))),
                        ],),

                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 30),
                        child: Text(cityDatamodel.cityname,style: TextStyle(color: Colors.white,fontSize: 30),),
                      ) ,
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(cityDatamodel.description,style: TextStyle(color: Colors.grey,fontSize: 20)),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child:
                        setIconForMain(cityDatamodel),
                        //    Icon(Icons.wb_sunny_outlined,color: Colors.white,size: 40,),
                        //         AnimatedIcon(icon: AnimatedIcons.add_event,progress: controller,)

                        // AnimatedDrawing.svg(
                        //      "assets/heavy_rain.svg",
                        //      run: true,
                        //      duration: new Duration(seconds: 3),
                        //    )


                        //     SvgPicture.asset(
                        //     'assets/heavy_rain.svg',
                        //     //  color: Colors.red,
                        //     semanticsLabel: 'Acme Logo'
                        //
                        // ),


                      ) ,
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(cityDatamodel.temp.toString()+"\u00B0",style: TextStyle(color: Colors.white,fontSize: 30)),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Column(
                            children: [
                              Text("max",style: TextStyle(color: Colors.grey,fontSize: 20),),
                              Padding(
                                padding: const EdgeInsets.only(top: 5),
                                child: Text(cityDatamodel.temp_max.toString()+"\u00B0",style: TextStyle(color: Colors.white,fontSize: 20),),
                              ),

                            ],
                          ) ,
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Container(
                              height: 40,
                              width: 1,
                              color: Colors.white,
                            ),
                          ) ,

                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Column(children: [
                              Text("min",style: TextStyle(color: Colors.grey,fontSize: 20),),
                              Padding(
                                padding: const EdgeInsets.only(top: 5),
                                child: Text(cityDatamodel.temp_min.toString()+"\u00B0",style: TextStyle(color: Colors.white,fontSize: 20),),
                              ),

                            ],),
                          )
                        ],
                      ) ,
                      Padding(
                        padding: const EdgeInsets.only(top: 15,bottom: 14),
                        child: Container(
                          color: Colors.grey,
                          height: 1,
                          width: double.infinity,
                        ),
                      ),
                      Container(
                          width: double.infinity,
                          height: 100,
                          child: Center(
                            child: StreamBuilder<List<Forecastdaysmodel>>(
                              stream: streamforecastdays.stream,
                              builder: (context,snapshot){
                                if(snapshot.hasData){
                                  List<Forecastdaysmodel>? forecastdays=snapshot.data;
                                  return ListView.builder(
                                      shrinkWrap: true,
                                      scrollDirection: Axis.horizontal,
                                      itemCount: 6
                                      ,itemBuilder: (BuildContext context,int pos){
                                    return listviewitem(forecastdays![pos+1]);
                                  });

                                }else{
                                  return Center(
                                    child: Container(child:  JumpingDotsProgressIndicator(
                                      color: Colors.black,

                                      fontSize: 60,
                                      dotSpacing: 2,
                                    ) ),
                                  );
                                }

                              },

                            ),
                          )
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 15,bottom: 14),
                        child: Container(
                          color: Colors.grey,
                          height: 1,
                          width: double.infinity,
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Column(children: [
                            Text("wind speed",style: TextStyle(color: Colors.grey,fontSize: 15),),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(cityDatamodel.windspeed.toString()+" m/s",style: TextStyle(color: Colors.white),),
                            ),
                          ],),
                          Padding(
                            padding: const EdgeInsets.only(left: 10,right: 10),
                            child: Container(
                              height: 30,
                              width: 1,
                              color: Colors.white,
                            ),
                          ) ,
                          Column(children: [
                            Text("humidity",style: TextStyle(color: Colors.grey,fontSize: 15),),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(cityDatamodel.humidity.toString(),style: TextStyle(color: Colors.white),),
                            ),
                          ],),
                          Padding(
                            padding: const EdgeInsets.only(left: 10,right: 10),
                            child: Container(
                              height: 30,
                              width: 1,
                              color: Colors.white,
                            ),
                          ) ,
                          Column(children: [
                            Text("sunset",style: TextStyle(color: Colors.grey,fontSize: 15),),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(sunset.toString(),style: TextStyle(color: Colors.white),),
                            ),
                          ],),
                          Padding(
                            padding: const EdgeInsets.only(left: 10,right: 10),
                            child: Container(
                              height: 30,
                              width: 1,
                              color: Colors.white,
                            ),
                          ) ,
                          Column(children: [
                            Text("sunrise",style: TextStyle(color: Colors.grey,fontSize: 15),),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(sunrise.toString(),style: TextStyle(color: Colors.white),),
                            ),
                          ],),

                        ],)
                    ],

                  ),
                ),
              );
          }else{
            return Center(
              child: Container(child:  JumpingDotsProgressIndicator(
                color: Colors.black,

                fontSize: 60,
                dotSpacing: 2,
              ) ),
            );
          }
        },

      ),
    );
  }
  Container listviewitem(Forecastdaysmodel forecastday){
    return Container(
        width: 70,
        height: 50,
        child: Card(
          elevation: 0,
          color: Colors.transparent,
          child: Column(children: [
            Text(forecastday.datatime,style: TextStyle(color: Colors.white,fontSize: 15),),
            Expanded(child: setIconForMain(forecastday)),
            Text(forecastday.temp.round().toString()+"\u00b0",style: TextStyle(color: Colors.white,fontSize: 20),)
          ],
          ),
        ));
  }
  Image setIconForMain(model) {
    String description = model.description;

    if (description == "clear sky") {
      return Image(image: AssetImage('images/sunny.png'));
    } else if (description == "few clouds") {
      return Image(image: AssetImage('images/sunny-to-cloudy.png'));
    } else if (description.contains("clouds")) {
      return Image(image: AssetImage('images/cloudy.png'));
    } else if (description.contains("thunderstorm")) {
      return Image(image: AssetImage('images/stormy.png'));
    } else if (description.contains("drizzle")) {
      return Image(image: AssetImage('images/sun-rain.png'));
    } else if (description.contains("rain")) {
      return Image(image: AssetImage('images/showers.png'));
    } else if (description.contains("snow")) {
      return Image(image: AssetImage('images/snowy.png'));
    } else {
      return Image(image: AssetImage('images/windy.png'));
    }
  }
  Future<CurrentCityDatamodel> SendRequestCurrentweather(String cityname) async {
    var apikey='b0f57e70523e3d8f3a773b6deafa3298';

    var response=await Dio().get("http://api.openweathermap.org/data/2.5/weather",queryParameters: {'q': cityname,'appid':apikey,'units':'metric'});
    lat=response.data["coord"]["lat"];
    lon=response.data["coord"]["lon"];
    var datamodel=CurrentCityDatamodel(
      response.data["name"],
      response.data["coord"]["lon"],
      response.data["coord"]["lat"],
      response.data["weather"][0]["main"],
      response.data["weather"][0]["description"],
      response.data["main"]["temp"],
      response.data["main"]["temp_min"],
      response.data["main"]["temp_max"],
      response.data["main"]["pressure"],
      response.data["main"]["humidity"],
      response.data["wind"]["speed"],
      response.data["dt"],
      response.data["sys"]["country"],
      response.data["sys"]["sunrise"],
      response.data["sys"]["sunset"],);
    //  print(response.data);
    //  print(response.statusCode);
    return datamodel;

  }
  void SendRequestSenvendaysforecast(lat,lon) async{
    List<Forecastdaysmodel> list=[];
    var apikey="b0f57e70523e3d8f3a773b6deafa3298";
    try{
      var response=await Dio().get("https://api.openweathermap.org/data/2.5/onecall",queryParameters: {
        'lat': lat,
        'lon': lon,
        'exclude': 'minutely,hourly',
        'appid': apikey,
        'units': 'metric'
      });
      final formatter=DateFormat.MMMd();
      for(int i=0;i<8;i++){
        var model=response.data['daily'][i];
        var dt=formatter.format(new DateTime.fromMillisecondsSinceEpoch(model['dt']*1000,isUtc:true));
        Forecastdaysmodel forecastdaysmodel=Forecastdaysmodel(dt, model['temp']['day'], model['weather'][0]['main'], model['weather'][0]['description']);
        list.add(forecastdaysmodel);
      }
      streamforecastdays.add(list);

    }on DioError catch (e){
      print(e.response!.statusCode);
      print(e.message);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("خطایی بوجود آمده")));
    }
  }




}

